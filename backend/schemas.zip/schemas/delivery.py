from pydantic import BaseModel, Field
from datetime import date
from typing import List, Optional
# Import related schemas
from backend.schemas.deliver import Deliver
from backend.schemas.ingredient import Ingredient
# Base schema for Delivery
class DeliveryBase(BaseModel):
    status: str = Field(..., title="Delivery Status")
    date: date = Field(..., title="Delivery Date")
    deliver_id: int = Field(..., title="Deliver ID")

# Create schema
class DeliveryCreate(DeliveryBase):
    ingredient_ids: List[int] = Field(..., title="Ingredient IDs")

# Update schema
class DeliveryUpdate(BaseModel):
    status: Optional[str] = Field(None, title="Delivery Status")
    date: Optional[date] = Field(None, title="Delivery Date")
    deliver_id: Optional[int] = Field(None, title="Deliver ID")
    ingredient_ids: Optional[List[int]] = Field(None, title="Ingredient IDs")

# Read schema
class Delivery(BaseModel):
    id: int
    status: str
    date: date
    deliver_id: int

    class Config:
        from_attributes = True

# Detailed schema with related objects
class DeliveryWithRelations(Delivery):
    related_deliver: "Deliver"  # Renamed from `deliverer` to avoid conflict
    ingredients: List["Ingredient"] = []


DeliveryWithRelations.update_forward_refs()
